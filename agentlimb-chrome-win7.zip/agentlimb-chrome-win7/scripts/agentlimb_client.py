#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AgentLimb HTTP RPC Client (Python 3.5+ / Win7 Compatible)
"""

import json
import urllib.request
import urllib.error

DEFAULT_PORTS = tuple(range(8765, 8781))


def get_bridge_url(host="127.0.0.1", ports=DEFAULT_PORTS):
    for port in ports:
        try:
            url = "http://{0}:{1}/health".format(host, port)
            req = urllib.request.Request(url)
            resp = urllib.request.urlopen(req, timeout=1.0)
            if resp.getcode() == 200:
                return "http://{0}:{1}/api/tool".format(host, port)
        except Exception:
            continue
    return "http://{0}:{1}/api/tool".format(host, ports[0])


def get_status(host="127.0.0.1", ports=DEFAULT_PORTS):
    for port in ports:
        try:
            url = "http://{0}:{1}/health".format(host, port)
            req = urllib.request.Request(url)
            resp = urllib.request.urlopen(req, timeout=1.0)
            if resp.getcode() == 200:
                body = resp.read().decode("utf-8")
                return json.loads(body)
        except Exception:
            continue
    return None


def call_tool(tool, arguments=None, timeout=60.0, host="127.0.0.1", ports=DEFAULT_PORTS):
    payload = {
        "tool": tool,
        "arguments": arguments or {},
        "timeoutMs": int(timeout * 1000),
    }
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    url = get_bridge_url(host=host, ports=ports)
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        resp = urllib.request.urlopen(req, timeout=timeout + 5)
        res = json.loads(resp.read().decode("utf-8"))
        if not res.get("ok"):
            raise RuntimeError("AgentLimb tool execution failed: {0}".format(res.get("error")))
        return res.get("result")
    except urllib.error.HTTPError as err:
        body = err.read().decode("utf-8") if err.fp else ""
        raise RuntimeError("HTTP {0}: {1}".format(err.code, body))


def eval_js(expression, browser=None, tab_id=None, timeout=60.0):
    args = {"expression": expression}
    if browser:
        args["browser"] = browser
    if tab_id is not None:
        args["tabId"] = int(tab_id)
    return call_tool("javascript_eval", args, timeout=timeout)


def get_tabs(browser=None):
    args = {}
    if browser:
        args["browser"] = browser
    res = call_tool("tabs_context", args)
    if isinstance(res, dict) and "result" in res:
        res = res["result"]
    if isinstance(res, dict) and "tabs" in res:
        return res["tabs"]
    return []


if __name__ == "__main__":
    print("Testing AgentLimb RPC Client...")
    status = get_status()
    if not status:
        print("No running AgentLimb bridge server found on ports 8765-8780.")
    else:
        print("Bridge found on port {0}: version {1}".format(status.get("port"), status.get("version")))
        browsers = status.get("browserList", [])
        print("Connected browsers: {0}".format(len(browsers)))
        for b in browsers:
            print("  - {0} (id: {1}, active: {2})".format(b.get("label"), b.get("id"), b.get("active")))
        tabs = get_tabs()
        print("Active browser open tabs: {0}".format(len(tabs)))
